#!/usr/bin/env python
#-*- coding:utf-8 -*-

from .core import FormatStr
from .pattern import *
from .guess import *
from .fmtemul import *